﻿namespace AppMAUI.Issue752_KotlinGeneratedByMoreThan;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
