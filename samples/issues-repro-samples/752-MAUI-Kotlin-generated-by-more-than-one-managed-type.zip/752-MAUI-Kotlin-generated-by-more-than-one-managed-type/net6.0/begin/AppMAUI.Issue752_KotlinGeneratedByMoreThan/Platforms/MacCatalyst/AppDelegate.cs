﻿using Foundation;

namespace AppMAUI.Issue752_KotlinGeneratedByMoreThan;

[Register("AppDelegate")]
public class AppDelegate : MauiUIApplicationDelegate
{
	protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}
