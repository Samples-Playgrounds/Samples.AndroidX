﻿using Android.App;
using Android.OS;
using Android.Runtime;
using AndroidX.AppCompat.App;
using AndroidX.Navigation;
using AndroidX.Navigation.Fragment;
using AndroidX.Navigation.UI;
using Google.Android.Material.BottomNavigation;

namespace App4
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        private NavController navController;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);

            SetContentView(Resource.Layout.activity_main);

            var navHostFragment = SupportFragmentManager.FindFragmentById(Resource.Id.nav_host_container) as NavHostFragment;
            navController = navHostFragment.NavController;
            var inflater = navController.NavInflater;
            //var graph = inflater.Inflate(Resource.Navigation.nav_graph);
            //navController.SetGraph(graph);

            var bottomNavigationView = FindViewById<BottomNavigationView>(Resource.Id.bottom_nav);

            NavigationUI.SetupWithNavController(bottomNavigationView, navController);
        }
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}