# XamarinProjects
Example Xamarin Android projects
