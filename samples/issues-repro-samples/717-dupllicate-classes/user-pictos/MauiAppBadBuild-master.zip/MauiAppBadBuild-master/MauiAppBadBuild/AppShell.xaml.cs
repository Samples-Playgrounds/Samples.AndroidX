﻿namespace MauiAppBadBuild;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
