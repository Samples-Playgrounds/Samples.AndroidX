﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.Internals;


namespace App41
{
    [Preserve(AllMembers = true)]
    public partial class AppShell : Xamarin.Forms.Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}
