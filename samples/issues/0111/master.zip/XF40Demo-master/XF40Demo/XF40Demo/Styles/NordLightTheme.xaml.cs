﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XF40Demo.Styles
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class NordLightTheme : ResourceDictionary
    {
		public NordLightTheme()
		{
			InitializeComponent ();
		}
	}
}