﻿using Xamarin.Forms;

namespace DemoAndroidXCrash
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            MainPage = new MainPage();
        }
    }
}
