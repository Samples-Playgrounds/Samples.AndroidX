﻿namespace Plugin.Fingerprint.Contract
{
    public enum FingerprintAuthenticationHelp
    {
        MovedTooFast,
        MovedTooSlow,
        Partial,
        Insufficient,
        Dirty
    }
}