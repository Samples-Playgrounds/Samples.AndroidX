---------------------------------
Xamarin and MvvmCross plugin for authenticating a user via fingerprint, face id or any other biometic / local authentication method from a cross platform API.
---------------------------------

How to setup:
Read carefully (especially the Android X part)! https://github.com/smstuebe/xamarin-fingerprint/tree/2.0.0

Star on Github at: https://github.com/smstuebe/xamarin-fingerprint

Feel free to buy me a bavarian beer: https://www.paypal.me/smstuebe