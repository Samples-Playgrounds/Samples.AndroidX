﻿using Xamarin.Forms;

namespace SMS.Fingerprint.Sample
{
    public partial class SecretView : ContentPage
    {
        public SecretView()
        {
            InitializeComponent();
        }
    }
}
