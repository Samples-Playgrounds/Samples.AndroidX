﻿using System;

namespace Toggl.Core.Tests.Sync.States
{
    internal sealed class TestException : Exception
    {
    }
}
