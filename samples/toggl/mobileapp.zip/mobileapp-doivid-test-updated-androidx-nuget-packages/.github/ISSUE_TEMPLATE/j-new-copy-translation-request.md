---
name: "🌏 New Copy Translation Request"
about: Newly added screens, some texts changed in the app? That's the right place.
title: "New Copy Translation Request - Issue/Feature/Screen"

---

**Target Languages:** 
<!-- Requested Languages Here -->
<!-- This kind of issue should usually only be created by the Toggl people, so please make sure you are listing all currently supported languages. -->

**New Copies:**
<!-- Copy and paste the permalink to the text entries to be translated, or simply paste them here in English. -->

---
Leave a comment in this issue if you'd like collaborate.
