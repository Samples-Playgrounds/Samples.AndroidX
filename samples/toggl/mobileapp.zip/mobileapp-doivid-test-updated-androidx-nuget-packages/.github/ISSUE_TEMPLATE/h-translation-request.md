---
name: "🌏 New Language Request"
about: Do you want the Toggl apps to be translated into another language? This is the right place! Please check that no other request for the same language has been made before submitting this issue.
title: "New Language Request - Examplanese, eg-EG"

---

**Target Language:** <!-- Requested Language Here -->

If you'd like to collaborate and help us with translating the app into the requested language, please let us know by commenting this issue.
