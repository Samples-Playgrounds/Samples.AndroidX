namespace Toggl.Core.Analytics
{
    public enum CalendarTimeEntryCreatedType
    {
        CopyFromCalendarEvent,
        StartFromCalendarEvent,
        LongPress
    }
}
