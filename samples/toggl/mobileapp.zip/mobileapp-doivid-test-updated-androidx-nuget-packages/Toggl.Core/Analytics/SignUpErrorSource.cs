﻿namespace Toggl.Core.Analytics
{
    public enum SignUpErrorSource
    {
        EmailIsAlreadyUsed,
        Offline,
        ServerError,
        Other
    }
}
