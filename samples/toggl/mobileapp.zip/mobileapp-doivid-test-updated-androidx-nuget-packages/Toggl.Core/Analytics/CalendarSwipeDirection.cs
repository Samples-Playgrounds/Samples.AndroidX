namespace Toggl.Core.Analytics
{
    public enum CalendarSwipeDirection
    {
        Left,
        Rignt
    }
}
