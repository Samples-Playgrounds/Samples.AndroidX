namespace Toggl.Core.Analytics
{
    public enum DeleteTimeEntryOrigin
    {
        EditView,
        LogSwipe,
        GroupedEditView,
        GroupedLogSwipe
    }
}
