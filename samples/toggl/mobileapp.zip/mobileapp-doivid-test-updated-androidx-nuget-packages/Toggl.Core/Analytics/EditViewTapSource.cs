﻿namespace Toggl.Core.Analytics
{
    public enum EditViewTapSource
    {
        Description,
        Project,
        Tags,
        StartTime,
        StartDate,
        StopTime,
        StopTimeLabel,
        Duration,
        Billable
    }
}
