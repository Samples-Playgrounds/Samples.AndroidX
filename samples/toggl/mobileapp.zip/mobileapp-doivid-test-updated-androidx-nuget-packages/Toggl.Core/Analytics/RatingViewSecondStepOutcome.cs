﻿namespace Toggl.Core.Analytics
{
    public enum RatingViewSecondStepOutcome
    {
        AppWasRated,
        AppWasNotRated,
        FeedbackWasLeft,
        FeedbackWasNotLeft
    }
}
