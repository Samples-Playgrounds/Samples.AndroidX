namespace Toggl.Core.Analytics
{
    public enum EditViewCloseReason
    {
        Save,
        SaveWithoutChange,
        Close,
        Delete,
        GroupSave,
        GroupSaveWithoutChange,
        GroupClose,
        GroupDelete
    }
}
