﻿namespace Toggl.Core.Analytics
{
    public enum LoginSignupAuthenticationMethod
    {
        Login,
        LoginGoogle,
        SignUp,
        SignUpWithGoogle
    }
}
