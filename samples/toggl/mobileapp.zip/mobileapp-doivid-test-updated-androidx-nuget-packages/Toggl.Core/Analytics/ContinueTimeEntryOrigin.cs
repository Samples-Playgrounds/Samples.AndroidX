namespace Toggl.Core.Analytics
{
    public enum ContinueTimeEntryOrigin
    {
        Swipe,
        ContinueButton,
        GroupSwipe,
        GroupContinueButton,
    }
}
