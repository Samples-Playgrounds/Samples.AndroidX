namespace Toggl.Core.Analytics
{
    public enum CalendarContextualMenuActionType
    {
        Discard,
        Edit,
        Save,
        Delete,
        CopyAsTimeEntry,
        StartFromCalendarEvent,
        Continue,
        Stop,
        Dismiss
    }
}