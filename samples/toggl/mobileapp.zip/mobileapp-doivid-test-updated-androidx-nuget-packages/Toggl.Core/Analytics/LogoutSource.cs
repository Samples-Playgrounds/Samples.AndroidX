﻿namespace Toggl.Core.Analytics
{
    public enum LogoutSource
    {
        Settings,
        TokenReset
    }
}
