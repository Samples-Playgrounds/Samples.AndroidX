﻿namespace Toggl.Core.Analytics
{
    public enum CalendarChangeEvent
    {
        Duration,
        StartTime
    }
}
