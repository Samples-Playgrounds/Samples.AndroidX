﻿namespace Toggl.Core.Analytics
{
    public enum CalendarSuggestionProviderState
    {
        Unauthorized,
        NoEvents,
        SuggestionsAvailable
    }
}
