﻿namespace Toggl.Core.Analytics
{
    public enum EditTimeEntryOrigin
    {
        RunningTimeEntryCard,
        SingleTimeEntry,
        GroupHeader,
        GroupTimeEntry
    }
}
