﻿namespace Toggl.Core.Analytics
{
    public enum ProjectTagSuggestionSource
    {
        TextField,
        ButtonOverKeyboard,
        TableCellButton
    }
}
