﻿namespace Toggl.Core.Analytics
{
    public enum AuthenticationMethod
    {
        EmailAndPassword,
        Google
    }
}
