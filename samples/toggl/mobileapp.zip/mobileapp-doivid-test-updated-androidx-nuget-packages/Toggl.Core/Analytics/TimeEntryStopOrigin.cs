namespace Toggl.Core.Analytics
{
    public enum TimeEntryStopOrigin
    {
        Manual,
        Deeplink,
        Siri,
        Widget,
        EditView,
        Wheel,
        CalendarContextualMenu
    }
}
