﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Toggl.Core
{
    public enum ApplicationInstallLocation
    {
        Internal,
        External,
        Unknown
    }
}
