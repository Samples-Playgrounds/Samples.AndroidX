namespace Toggl.Core.UI.Helper
{
    public enum UpcomingEventsOption
    {
        Disabled,
        WhenEventStarts,
        FiveMinutes,
        TenMinutes,
        FifteenMinutes,
        ThirtyMinutes,
        OneHour
    }
}
