using System.Globalization;

namespace Toggl.Core.UI.Helper
{
    public static class DateFormatCultureInfo
    {
        public static CultureInfo CurrentCulture { get; set; }
    }
}
