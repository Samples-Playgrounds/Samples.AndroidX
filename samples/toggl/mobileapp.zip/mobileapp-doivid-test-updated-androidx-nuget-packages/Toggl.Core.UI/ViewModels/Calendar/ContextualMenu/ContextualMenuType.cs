namespace Toggl.Core.UI.ViewModels.Calendar.ContextualMenu
{
    public enum ContextualMenuType
    {
        NewTimeEntry,
        StoppedTimeEntry,
        RunningTimeEntry,
        CalendarEvent,
        Closed
    }
}