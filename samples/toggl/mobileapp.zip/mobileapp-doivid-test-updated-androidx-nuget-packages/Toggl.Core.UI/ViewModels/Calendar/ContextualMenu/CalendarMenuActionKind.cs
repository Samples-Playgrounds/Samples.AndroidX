namespace Toggl.Core.UI.ViewModels.Calendar.ContextualMenu
{
    public enum CalendarMenuActionKind
    {
        Discard,
        Edit,
        Save,
        Delete,
        Copy,
        Start,
        Continue,
        Stop
    }
}