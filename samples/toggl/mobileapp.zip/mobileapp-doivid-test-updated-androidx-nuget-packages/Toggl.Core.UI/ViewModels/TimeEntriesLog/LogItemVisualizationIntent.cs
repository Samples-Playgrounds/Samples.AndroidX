namespace Toggl.Core.UI.ViewModels.TimeEntriesLog
{
    public enum LogItemVisualizationIntent
    {
        SingleItem,
        ExpandedGroupHeader,
        CollapsedGroupHeader,
        GroupItem
    }
}
