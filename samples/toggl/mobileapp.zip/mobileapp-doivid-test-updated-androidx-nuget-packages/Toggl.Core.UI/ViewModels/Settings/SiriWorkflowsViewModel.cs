using Toggl.Core.UI.Navigation;

namespace Toggl.Core.UI.ViewModels.Settings
{
    public class SiriWorkflowsViewModel : ViewModel
    {
        public SiriWorkflowsViewModel(INavigationService navigationService) : base(navigationService)
        {
        }
    }
}
