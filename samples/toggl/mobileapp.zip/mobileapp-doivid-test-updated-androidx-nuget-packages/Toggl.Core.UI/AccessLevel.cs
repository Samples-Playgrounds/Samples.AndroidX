﻿namespace Toggl.Core.UI
{
    public enum AccessLevel
    {
        AccessRestricted,
        NotLoggedIn,
        TokenRevoked,
        LoggedIn,
    }
}
