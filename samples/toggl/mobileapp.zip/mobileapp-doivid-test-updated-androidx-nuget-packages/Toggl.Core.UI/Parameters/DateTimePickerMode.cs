﻿namespace Toggl.Core.UI.Parameters
{
    public enum DateTimePickerMode
    {
        Date,
        Time,
        DateTime
    }
}
