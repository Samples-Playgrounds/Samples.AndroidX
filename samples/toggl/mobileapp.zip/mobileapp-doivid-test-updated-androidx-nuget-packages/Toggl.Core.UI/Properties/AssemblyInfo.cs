﻿using System.Reflection;
using System.Runtime.CompilerServices;
using Toggl.Shared;

// Information about this assembly is defined by the following attributes. 
// Change them to the values specific to your project.

[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: InternalsVisibleTo("Toggl.Core.Tests")]
[assembly: LinkerSafe]
