Data Binding Demos
==================

This sample demonstrates data binding in both code and XAML.

For more information about this code, see the article [Data Binding](https://developer.xamarin.com/guides/xamarin-forms/application-fundamentals/data-binding/).

Author
------

Charles Petzold
