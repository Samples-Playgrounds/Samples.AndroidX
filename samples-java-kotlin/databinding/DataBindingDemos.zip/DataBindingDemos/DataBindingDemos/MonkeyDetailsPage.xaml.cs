﻿using Xamarin.Forms;

namespace DataBindingDemos
{
    public partial class MonkeyDetailsPage : ContentPage
    {
        public MonkeyDetailsPage()
        {
            InitializeComponent();
        }
    }
}
