﻿using Xamarin.Forms;

namespace DataBindingDemos
{
    public partial class ReverseBindingPage : ContentPage
    {
        public ReverseBindingPage()
        {
            InitializeComponent();
        }
    }
}