﻿using Xamarin.Forms;

namespace DataBindingDemos
{
    public partial class CompiledColorListPage : ContentPage
    {
        public CompiledColorListPage()
        {
            InitializeComponent();
        }
    }
}
