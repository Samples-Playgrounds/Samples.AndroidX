﻿using Xamarin.Forms;

namespace DataBindingDemos
{
    public partial class RgbColorSelectorPage : ContentPage
    {
        public RgbColorSelectorPage()
        {
            InitializeComponent();
        }
    }
}