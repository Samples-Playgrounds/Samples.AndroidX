﻿using Xamarin.Forms;

namespace DataBindingDemos
{
    public partial class AlternativeXamlBindingPage : ContentPage
    {
        public AlternativeXamlBindingPage()
        {
            InitializeComponent();
        }
    }
}