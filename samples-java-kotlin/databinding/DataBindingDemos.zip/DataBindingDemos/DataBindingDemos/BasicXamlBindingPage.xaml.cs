﻿using Xamarin.Forms;

namespace DataBindingDemos
{
    public partial class BasicXamlBindingPage : ContentPage
    {
        public BasicXamlBindingPage()
        {
            InitializeComponent();
        }
    }
}