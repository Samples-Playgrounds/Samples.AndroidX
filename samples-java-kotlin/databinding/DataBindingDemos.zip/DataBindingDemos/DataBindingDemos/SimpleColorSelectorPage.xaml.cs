﻿using Xamarin.Forms;

namespace DataBindingDemos
{
    public partial class SimpleColorSelectorPage : ContentPage
    {
        public SimpleColorSelectorPage()
        {
            InitializeComponent();
        }
    }
}