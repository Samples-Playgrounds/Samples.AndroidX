﻿using Xamarin.Forms;

namespace DataBindingDemos
{
    public partial class StringFormattingPage : ContentPage
    {
        public StringFormattingPage()
        {
            InitializeComponent();
        }
    }
}