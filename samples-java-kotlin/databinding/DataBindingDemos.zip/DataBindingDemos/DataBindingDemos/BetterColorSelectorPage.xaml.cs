﻿using Xamarin.Forms;

namespace DataBindingDemos
{
    public partial class BetterColorSelectorPage : ContentPage
    {
        public BetterColorSelectorPage()
        {
            InitializeComponent();
        }
    }
}