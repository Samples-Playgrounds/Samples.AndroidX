﻿using Xamarin.Forms;

namespace DataBindingDemos
{
    public partial class CompiledColorSelectorPage : ContentPage
    {
        public CompiledColorSelectorPage()
        {
            InitializeComponent();
        }
    }
}
